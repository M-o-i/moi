
(function (exports, require, module, __filename, __dirname) {

})

class tyyppi {
    constructor(nimi, ika) {
        this.nimi = nimi;
        this.ika = ika;
    }

    greeting() {
        console.log(`miun nimi on ${this.nimi} ja olen ${this.ika}`)
    }
}

module.exports = tyyppi;