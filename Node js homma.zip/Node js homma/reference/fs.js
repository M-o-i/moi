const fs = require('fs');
const path = require('path');


// Create folder
 fs.mkdir(path.join(__dirname, '/test'), {}, err => {
   if (err) throw err;
  console.log('Filu thety');
 });

// Create and write to file
 fs.writeFile(
   path.join(__dirname, '/test', 'Terve.txt'),
   'Helou',  err => {
     if (err) throw err;
     console.log('Filu kirjattu');

// File append
   fs.appendFile(
       path.join(__dirname, '/test', 'Terve.txt'),
       'Vanmasta',
       err => {
         if (err) throw err;
         console.log('Tiedosto kirjaty');
       }
     );
  }
 );

// Read file
fs.readFile(path.join(__dirname, '/test', 'Terve.txt'), 'utf8', (err, data) => {
console.log(data);
 });

// Rename file
fs.rename(
    path.join(__dirname, '/test', 'Terve.txt'),
    path.join(__dirname, '/test', 'hellurei.txt'),
    err => {
      if (err) throw err;
      console.log('Filu uusix nimetty');
    }
  );
